
package domain;

public enum Flag {

	ACTIVE, PASSED, DELETED

}
